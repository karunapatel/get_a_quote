<?php
/*
 * @author Daniel Taylor <dtaylor@rvos.com>
 * Contains \Drupal\payment\Form\PaymentForm.
 */
namespace Drupal\payment\Form;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Render\Element;
use Drupal\Core\Url;
use Drupal\payment\Service\PaymentHttpClientService;
use Drupal\payment\Service\PaymentXmlrpcService;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Mail\MailManagerInterface;
use Drupal\Core\Language\LanguageManagerInterface;
use Drupal\Core\Mail\MailFormatHelper;

/**
 * Handles the form building, validation, and submission for a RVOS web payment.
 */
class PaymentForm extends FormBase
{

  /**
   * The mail manager.
   *
   * @var \Drupal\Core\Mail\MailManagerInterface
   */
  protected $mailManager;

  /**
   * The language manager.
   *
   * @var \Drupal\Core\Language\LanguageManagerInterface
   */
  protected $languageManager;

  /**
   * @var array
   */
  private $steps;

  /**
   * @var Drupal\payment\Service\PaymentHttpClientService
   */
  private $accountService;

  /**
   * @var Drupal\payment\Service\PaymentXmlrpcService
   */
  private $paymentService;

  /**
   * Constructs a \Drupal\payment\Form\PaymentForm object.
   * Customized constructor for PaymentForm.
   * @param PaymentHttpClientService $payment_service
   */
  public function __construct(PaymentHttpClientService $account_service, PaymentXmlrpcService $payment_service, ConfigFactoryInterface $config_factory, MailManagerInterface $mail_manager, LanguageManagerInterface $language_manager)
  {
    // Query customer account information.
    $this->accountService = $account_service;
    // Submit payments and generate receipts.
    $this->paymentService = $payment_service;
    // The configuration for this module.
    $this->config = $config_factory->get('payment.settings');
    $this->mailManager = $mail_manager;
    $this->languageManager = $language_manager;
  }

  /**
   * Creates a \Drupal\payment\Form\PaymentForm object.
   * @param ContainerInterface $container
   * @return \Drupal\payment\Form\PaymentForm
   */
  public static function create(ContainerInterface $container)
  {
    return new static(
      $container->get('payment.http_client_service'), $container->get('payment.xmlrpc_service'), $container->get('config.factory'), $container->get('plugin.manager.mail'), $container->get('language_manager')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId(): string
  {
    return 'payment_form';
  }

  /**
   * Builds the steps necessary for navigating this multi-step form.
   * @return array
   */
  public function buildSteps()
  {
    return [
      1 => 'accountSearch',
      2 => 'accountDetails',
      3 => 'confirmPayment',
      4 => 'paymentSuccess'
    ];
  }

  /**
   * Search for a customer's account information.
   * 
   * @param array $form
   * @param FormStateInterface $form_state
   */
  protected function accountSearch(array &$form, FormStateInterface $form_state)
  {

    $form['search_info_markup'] = array(
      '#type' => 'item',
      '#markup' => '<div id = "search_info_markup"><p>Pay your bill or view account balance. <br />
      Please enter your account details:</p>
      </div>',
    );

    $form['search_account_number'] = array(
      '#type' => 'textfield',
      '#title' => t('Account Number'),
      '#required' => TRUE,
      '#default_value' => !empty($form_state->getValue('search_account_number')) ? $form_state->getValue('search_account_number') : '',
      '#attributes' => array(
        'class' => array('search_account_number'),
      ),
    );

    $form['search_billing_zip'] = array(
      '#type' => 'textfield',
      '#title' => t('Billing Zip Code'),
      '#required' => TRUE,
      '#default_value' => !empty($form_state->getValue('search_billing_zip')) ? $form_state->getValue('search_billing_zip') : '',
      '#attributes' => array(
        'class' => array('search_entered_zip'),
      ),
      '#maxlength' => 5,
    );

    $form['search_info_markup2'] = array(
      '#type' => 'item',
      '#markup' => '<div id = "account_search_markup">
      <P>Note: payments to accounts that are past due still may result in cancellation. If your account is past due, please call customer service at 1-800-792-3084 to ensure continued coverage.</div>',
    );
  }

  /**
   * Validate the customer's account information.
   *
   * @param array $form
   * @param FormStateInterface $form_state
   */
  protected function accountSearchValidate(array $form, FormStateInterface $form_state)
  {
    if (strlen($form_state->getValue('search_billing_zip')) != 5) {
      $form_state->setError($form['search_billing_zip'], t('%zip is invalid. Please enter a five digit zip code.', ['%zip' => $form['search_billing_zip']['#title']]));
    }

    // Don't process the webservice call if we have form_state errors....
    if (count($form_state->getErrors()) > 0) {
      return;
    }

    // Web service call to get customer account information.
    // Retrieve the account information.
    $ws_result = $this->accountService->retrieveCustomerInformation($form_state);
    if (empty($ws_result) || false === $ws_result) {
      $form_state->setErrorByName('search_account_number', t('Account not found. Please verify the account look up information an try again.'));
      return;
    }

    // Check for email on account
    if ($ws_result['email']) {
      $form_state->setValue('email_obscured', $this->format_email_obscured(strtolower($ws_result['email'])));
    }

    // Set the account information in the form state.
    // The submitForm() method will save this information to the current step
    // storage in form_state as ['storage', 'accountSearch']

    $form_state->setValue('account_number', $ws_result['accountNumber']);
    $form_state->setValue('full_name', $ws_result['fullName']);
    $form_state->setValue('email', strtolower($ws_result['email']));
    $form_state->setValue('balance', $this->toInt($ws_result['balance']));
    $form_state->setValue('minimum_due', $this->toInt($ws_result['minimumDue']));
    $form_state->setValue('due_date', date("F d, Y", strtotime($ws_result['dueDate'])));
    $form_state->setValue('past_due', $ws_result['pastDue']);
  }

  /**
   * Submit the customer's account information
   *
   * @param array $form
   * @param FormStateInterface $form_state
   */
  protected function accountSearchSubmit(array &$form, FormStateInterface $form_state)
  {

  }

  /**
   * The customer's account details and payment options.
   *
   * @param array $form
   * @param FormStateInterface $form_state
   */
  protected function accountDetails(array &$form, FormStateInterface $form_state)
  {
    $form['account_number'] = [
      '#type' => 'hidden',
      '#value' => $form_state->getValue('account_number'),
    ];

    $form['full_name'] = [
      '#type' => 'hidden',
      '#value' => $form_state->getValue('full_name'),
    ];

    $form['balance'] = [
      '#type' => 'hidden',
      '#value' => $form_state->getValue('balance'),
    ];

    $form['minimum_due'] = [
      '#type' => 'hidden',
      '#value' => $form_state->getValue('minimum_due'),
    ];

    $form['due_date'] = [
      '#type' => 'hidden',
      '#value' => $form_state->getValue('due_date'),
    ];

    $form['past_due'] = [
      '#type' => 'hidden',
      '#value' => $form_state->getValue('past_due'),
    ];

    $emailSysStatus = $this->config->get('payment_send_receipt_emails');
    if ($emailSysStatus == 'disallow') {
      drupal_set_message('NOTE: Emails have been turned off by configuration options. No receipt email will be sent. Change this for production.');
    }

    $form['account_details_page_details'] = array(
      '#markup' => $this->build_account_details_info($form_state),
    );

    // if there is no remaining balance, bail on the process.
    if ($form_state->getValue('balance') == 0) {
      drupal_set_message('You have no balance due at this time. You may still make a payment if you choose.');
    }

    $form['amount_to_pay'] = array(
      '#type' => 'item',
      '#title' => t('How much would you like to pay?'),
    );

    if ($form_state->getValue('minimumDue') != 0) {
      $form['amount_to_pay']['next_due_amount'] = array(
        '#type' => 'radio',
        '#title' => t('Total amount due now: $@min_due' . ['@min_due' => $form_state->getValue('minimum_due')]),
        '#default_value' => !empty($form_state->getValue('amount_to_pay')) ? $form_state->getValue('amount_to_pay') : 1,
        '#return_value' => 1,
        '#parents' => array('amount_to_pay'),
      );
    }

    $form['amount_to_pay']['remaining_balance_amount'] = array(
      '#type' => 'radio',
      '#title' => t('Total remaining balance on policy: $@balance', ['@balance' => $form_state->getValue('balance')]),
      '#default_value' => !empty($form_state->getValue('amount_to_pay')) ? $form_state->getValue('amount_to_pay') : 1,
      '#return_value' => 2,
      '#parents' => array('amount_to_pay'),
    );

    $form['amount_to_pay']['other_option'] = array(
      '#type' => 'radio',
      '#title' => t('Other Amount'),
      '#default_value' => !empty($form_state->getValue('amount_to_pay')) ? $form_state->getValue('amount_to_pay') : 1,
      '#return_value' => 3,
      '#parents' => array('amount_to_pay'),
    );

    $form['other_payment_amount'] = array(
      '#type' => 'textfield',
      '#default_value' => !empty($form_state->getValue('other_payment_amount')) ? $form_state->getValue('other_payment_amount') : '',
      '#size' => 10,
      '#field_prefix' => '$',
      //this must go in the last radio area to parse!
      '#states' => array(
        'visible' => array(
          ':input[name="amount_to_pay"]' => array('value' => "3"),
        ),
      ),
    );

    $email_options = $this->format_email_options($form_state);

    $form['email_receipts'] = array(
      '#type' => 'radios',
      '#title' => t('Email for payment confirmation' . $email_options['email_title']),
      '#options' => $email_options['payee_email_address'],
      '#default_value' => !empty($form_state->getValue('email_receipts')) ? $form_state->getValue('email_receipts') : strval($email_options['default_email_selection']),
    );

    $form['email_receipts']['new_email'] = array(
      '#default_value' => !empty($form_state->getValue('new_email')) ? $form_state->getValue('new_email') : '',
      '#type' => 'textfield',
      '#size' => 50,
      '#weight' => 10,
      '#description' => $email_options['email_description'],
      '#states' => array(
        'visible' => array(
          ':input[name="email_receipts"]' => array('value' => "1"),
        ),
      ),
    );

    $form['account_details_payment_method'] = array(
      '#title' => t('Payment Information'),
      '#type' => 'radios',
      '#options' => array('CC' => 'Credit card', 'EFT' => 'Electronic Funds Transfer (Bank draft)'),
      '#default_value' => !empty($form_state->getValue('account_details_payment_method')) ? $form_state->getValue('account_details_payment_method') : '',
    );


    // Credit Card form
    $cc_url = drupal_get_path('module', 'payment') . "/images/newCC.gif";

    $form['account_details_payment_method']['credit_card_details'] = array(
      '#type' => 'fieldset',
      '#title' => t('Credit Card Details'),
      '#collapsible' => FALSE,
      '#weight' => 10,
      '#states' => array(
        'visible' => array(
          ':input[name="account_details_payment_method"]' => array('value' => 'CC'),
        ),
      ),
      '#prefix' => '<div id="credit_card_details">',
      '#suffix' => '</div>',
    );

    $form['account_details_payment_method']['credit_card_details']['cc_image'] = array(
      '#type' => 'item',
      '#markup' => '<div id = "check-image"><img src = /' . $cc_url . '></div>',
    );

    $form['account_details_payment_method']['credit_card_details']['cc_details_warning'] = array(
      '#type' => 'item',
      '#markup' => '<BR><div id = "billing-info-warning">Please enter the billing name and billing address associated with the credit card.</div>',
    );

    $form['account_details_payment_method']['credit_card_details']['card_number'] = array(
      '#type' => 'textfield',
      '#title' => t('Card Number'),
      '#size' => 20,
      '#maxlength' => 16,
      //'#required' => TRUE,
      '#description' => t('No dashes or spaces'),
      '#default_value' => !empty($form_state->getValue('card_number')) ? $form_state->getValue('card_number') : '',
    );

    $form['account_details_payment_method']['credit_card_details']['month'] = array(
      '#type' => 'select',
      //'#required' => TRUE,
      '#title' => t('Month'),
      '#options' => array(
        '1' => '01 - Jan',
        '2' => '02 - Feb',
        '3' => '03 - Mar',
        '4' => '04 - Apr',
        '5' => '05 - May',
        '6' => '06 - Jun',
        '7' => '07 - Jul',
        '8' => '08 - Aug',
        '9' => '09 - Sep',
        '10' => '10 - Oct',
        '11' => '11 - Nov',
        '12' => '12 - Dec'),
      // '#default_value' => '1',
      '#default_value' => !empty($form_state->getValue('billing_zip_code')) ? $form_state->getValue('billing_zip_code') : 1,
    );

    $year_values = array();
    for ($j = date('Y'), $i = 0; $i < 11; $i++) {
      $year_values[$j + $i] = $j + $i;
    }

    $form['account_details_payment_method']['credit_card_details']['year'] = array(
      '#type' => 'select',
      '#title' => t('Year'),
      '#options' => $year_values,
      '#default_value' => -1,
      //'#required' => TRUE,
      '#default_value' => !empty($form_state->getValue('year')) ? $form_state->getValue('year') : '',
    );

    $form['account_details_payment_method']['credit_card_details']['card_verification_number'] = array(
      '#type' => 'textfield',
      '#title' => t('CCV number'),
      '#size' => 4,
      '#maxlength' => 4,
      //'#required' => TRUE,
      '#default_value' => !empty($form_state->getValue('card_verification_number')) ? $form_state->getValue('card_verification_number') : '',
      '#description' => t('This is the 3 or 4 digit code found on the card'),
    );

    $form['account_details_payment_method']['credit_card_details']['billing_first_name'] = array(
      '#type' => 'textfield',
      '#title' => t('Billing first name'),
      '#prefix' => '<BR clear = "all">',
      '#size' => 40,
      '#maxlength' => 35,
      //'#required' => TRUE,
      '#default_value' => !empty($form_state->getValue('billing_first_name')) ? $form_state->getValue('billing_first_name') : '',
    );

    $form['account_details_payment_method']['credit_card_details']['billing_last_name'] = array(
      '#type' => 'textfield',
      '#title' => t('Billing last name'),
      '#default_value' => !empty($form_state->getValue('billing_last_name')) ? $form_state->getValue('billing_last_name') : '',
      '#size' => 40,
      '#maxlength' => 35,
      //'#required' => TRUE,
    );

    $form['account_details_payment_method']['credit_card_details']['billing_street'] = array(
      '#type' => 'textfield',
      '#title' => t('Billing address'),
      '#default_value' => !empty($form_state->getValue('billing_street')) ? $form_state->getValue('billing_street') : '',
      '#size' => 40,
      // '#required' => TRUE,
    );

    $form['account_details_payment_method']['credit_card_details']['billing_city'] = array(
      '#type' => 'textfield',
      // '#required' => TRUE,
      '#title' => t('City'),
      '#size' => 40,
      '#maxlength' => 40,
      '#default_value' => !empty($form_state->getValue('billing_city')) ? $form_state->getValue('billing_city') : '',
    );

    $defaultState = 'TX';
    $form['account_details_payment_method']['credit_card_details']['billing_state'] = array(
      '#type' => 'select',
      '#title' => t('State'),
      //'#required' => TRUE,
      '#options' => array(
        'AL' => 'Alabama',
        'AK' => 'Alaska',
        'AZ' => 'Arizona',
        'AR' => 'Arkansas',
        'CA' => 'California',
        'CO' => 'Colorado',
        'CT' => 'Connecticut',
        'DE' => 'Delaware',
        'FL' => 'Florida',
        'GA' => 'Georgia',
        'HI' => 'Hawaii',
        'ID' => 'Idaho',
        'IL' => 'Illinois',
        'IN' => 'Indiana',
        'IA' => 'Iowa',
        'KS' => 'Kansas',
        'KY' => 'Kentucky',
        'LA' => 'Louisiana',
        'ME' => 'Maine',
        'MD' => 'Maryland',
        'MA' => 'Massachusetts',
        'MI' => 'Michigan',
        'MN' => 'Minnesota',
        'MS' => 'Mississippi',
        'MO' => 'Missouri',
        'MT' => 'Montana',
        'NE' => 'Nebraska',
        'NV' => 'Nevada',
        'NH' => 'New Hampshire',
        'NJ' => 'New Jersey',
        'NM' => 'New Mexico',
        'NY' => 'New York',
        'NC' => 'North Carolina',
        'ND' => 'North Dakota',
        'OH' => 'Ohio',
        'OK' => 'Oklahoma',
        'OR' => 'Oregon',
        'PA' => 'Pennsylvania',
        'RI' => 'Rhode Island',
        'SC' => 'South Carolina',
        'SD' => 'South Dakota',
        'TN' => 'Tennessee',
        'TX' => 'Texas',
        'UT' => 'Utah',
        'VT' => 'Vermont',
        'VA' => 'Virginia',
        'WA' => 'Washington',
        'WV' => 'West Virginia',
        'WI' => 'Wisconsin',
        'WY' => 'Wyoming'
      ),
      '#default_value' => !empty($form_state->getValue('billing_state')) ? $form_state->getValue('billing_state') : $defaultState,
      // '#default_value' => $defaultState,
    );

    $form['account_details_payment_method']['credit_card_details']['billing_zip_code'] = array(
      '#type' => 'textfield',
      '#title' => t('Zip'),
      '#size' => 9,
      '#maxlength' => 9,
      '#default_value' => !empty($form_state->getValue('billing_zip_code')) ? $form_state->getValue('billing_zip_code') : '',
    );

    //EFT Fields
    $check_url = drupal_get_path('module', 'payment') . "/images/check2.gif";

    $form['account_details_payment_method']['eft_group'] = array(
      '#type' => 'fieldset',
      '#title' => t('Banking Information'),
      '#weight' => 10,
      '#states' => array(
        'visible' => array(
          ':input[name="account_details_payment_method"]' => array('value' => 'EFT'),
        ),
      ),
      '#collapsible' => FALSE,
      '#prefix' => '<div id="eft_details">',
      '#description' => 'Electronic Funds Transfer (EFT) will debit your bank account electronically without the need for a paper check. The routing and account number can be found on your paper checks.',
      '#suffix' => '</div>',
    );

    $form['account_details_payment_method']['eft_group']['check_pic'] = array(
      '#type' => 'item',
      '#markup' => '<br><div id = "check-image"><img src = /' . $check_url . '></div><br>',
    );

    $form['account_details_payment_method']['eft_group']['eft_routing_number'] = array(
      '#type' => 'textfield',
      '#title' => t('Routing Number'),
      '#size' => 15,
      '#maxlength' => 15,
      '#description' => '[Red group]',
      '#default_value' => !empty($form_state->getValue('eft_routing_number')) ? $form_state->getValue('eft_routing_number') : '',
    );

    $form['account_details_payment_method']['eft_group']['eft_account_number'] = array(
      '#type' => 'textfield',
      '#title' => t('Account Number'),
      '#size' => 15,
      '#maxlength' => 15,
      //'#required' => TRUE,
      '#description' => '[Green group]',
      '#default_value' => !empty($form_state->getValue('eft_account_number')) ? $form_state->getValue('eft_account_number') : '',
    );

    $form['account_details_payment_method']['eft_group']['eft_account_type'] = array(
      '#type' => 'select',
      //'#required' => TRUE,
      '#title' => t('Account type'),
      '#options' => array('checking' => 'Checking', 'savings' => 'Savings'),
      '#default_value' => !empty($form_state->getValue('eft_account_type')) ? $form_state->getValue('eft_account_type') : -1,
      '#description' => '',
    );

    $form['account_details_payment_method']['eft_group']['eft_name'] = array(
      '#type' => 'textfield',
      '#title' => t('Name on Bank Account'),
      '#prefix' => '<BR clear = "all"><BR>',
      '#size' => 60,
      '#maxlength' => 60,
      //'#required' => TRUE,
      '#default_value' => !empty($form_state->getValue('eft_name')) ? $form_state->getValue('eft_name') : '',
    );
  }
// end accountdetails

  /**
   * Validate the customer's selected payment options.
   *
   * @param array $form
   * @param FormStateInterface $form_state
   */
  protected function accountDetailsValidate(array &$form, FormStateInterface $form_state)
  {
    //validate email
    if ($form_state->getValue('email_receipts') == 0) {
      // dsm('you chose to use the address on file');
      if (!valid_email_address($form_state->getValue('email'))) {
        $form_state->setErrorByName('email', t('The e-mail address on file is not valid.
        Please enter an alternative email address. This address will be used for this transaction only. To update your email on file, please call customer service at 1-800-792-3084.'));
      }
    } else {
      // dsm('you chose to NOT use the address on file');
      if (!valid_email_address($form_state->getValue('new_email'))) {
        $form_state->setErrorByName('email', t('The e-mail address is not valid. Please re-enter.'));
      }
    }

    // Validate that a payment method was chosen. we are doing this manually rather than using drupal native #required to deal with stepping backward through the form.
    // If stepping back to the account search screen, this was throwing errors if no payment information was selected. Buggy.

    if ($form_state->getValue('account_details_payment_method') != 'CC' && $form_state->getValue('account_details_payment_method') != 'EFT') {
      $form_state->setError($form['account_details_payment_method'], t('%payment is required. Please choose a payment method.', ['%payment' => $form['account_details_payment_method']['#title']]));
    }

    //validate CC inputs to ensure data
    if ($form_state->getValue('account_details_payment_method') == 'CC') {
      if (!$form_state->getValue('card_number')) {
        $form_state->setErrorByName('card_number', t('Please enter the credit card number.'));
      }
      if (!$form_state->getValue('card_verification_number')) {
        $form_state->setErrorByName('card_verification_number', t('Please enter the credit card verification number, usually a 3 digit number found on the back of the card. For AMEX it is the 4 digit number on the front of the card.'));
      }
      if ((!$form_state->getValue('billing_first_name')) || (!$form_state->getValue('billing_last_name'))) {
        $form_state->setErrorByName('card_first_name', t('Please enter the name associated with the billing address of the credit card.'));
      }
      if ((!$form_state->getValue('billing_street')) || (!$form_state->getValue('billing_city')) || (!$form_state->getValue('billing_state'))) {
        $form_state->setErrorByName('eft_routing_number', t('Please enter a full billing address.'));
      }
      if (strlen($form_state->getValue('billing_zip_code')) < 5) {
        $form_state->setErrorByName('zip', t('Please enter a valid zip code.'));
      }
      //credit card month validation, if user selects month value is less than current year month value, then system will throw an validation error message.
      $currentmonth = date("d - M");
      $currentyear = date("Y");
      if ($form_state->getValue('month') < $currentmonth && $form_state->getValue('year') == $currentyear) {
        $form_state->setErrorByName('month', t('Please select a valid month.'));
      }
    }

    //validate EFT inputs to ensure data
    if ($form_state->getValue('account_details_payment_method') == 'EFT') {
      if (!$form_state->getValue('eft_routing_number')) {
        $form_state->setErrorByName('eft_routing_number', t('Please enter your bank routing number.'));
      }
      if (!$form_state->getValue('eft_account_number')) {
        $form_state->setErrorByName('eft_account_number', t('Please enter your bank account number.'));
      }
      if (!$form_state->getValue('eft_account_type')) {
        $form_state->setErrorByName('eft_account_type', t('Please enter the bank account type.'));
      }
      if (!$form_state->getValue('eft_name')) {
        $form_state->setErrorByName('eft_name', t('Please enter the name of the bank account holder.'));
      }
    }

    // need to make sure this is giving a double float not further
    $other_amount_formatted = number_format(floatval($form_state->getValue('other_payment_amount')), 2, '.', ',');

    //check for extra characters before sanitizing that might lead to customer confusion
    $sanitizePattern = '/^\d*\.?\d*$/';
    if ($form_state->getValue('amount_to_pay') == '3' && !preg_match($sanitizePattern, $form_state->getValue('other_payment_amount'))) {
      $form_state->setErrorByName('other_payment_amount', t('There was an error with the amount to pay that was entered. Please enter an amount to pay that is formatted as a number with no additional characters.'));
    }
    //check sanitized version if entering an 'other amount' to pay
    elseif (($form_state->getValue('amount_to_pay') == '3') && $other_amount_formatted <= 0) {
      $form_state->setErrorByName('other_payment_amount', t('Please enter a positive value to pay.'));
    }
    //set values going forward to sanitized amount if entering an 'other amount' to pay
    elseif ($form_state->getValue('amount_to_pay') == '3' && $other_amount_formatted > 0) {
      //dsm('other payment amount was positive.');
      //$form_state->getValue('other_payment_amount') = $other_amount_formatted;
    }
    //shouldn't happen, but validate that the webservice is giving positive values
    elseif (($form_state->getValue('amount_to_pay') == '1') && $form_state->getValue('minimumDue') <= 0) {
      $form_state->setErrorByName('minimumDue', t('Please enter a positive value to pay.'));
    } elseif (($form_state->getValue('amount_to_pay') == '2') && $form_state->getValue('balance') <= 0) {
      //form_set_error('amount','Please enter a positive value to pay');
      $form_state->setErrorByName('balance', t('Please enter a positive value to pay.'));
    }
  }

  /**
   * Submit the customer's selected payment options.
   *
   * @param array $form
   * @param FormStateInterface $form_state
   */
  protected function accountDetailsSubmit(array &$form, FormStateInterface $form_state)
  {

  }

  /**
   * Confirm the customer's payment selections.
   *
   * @param array $form
   * @param FormStateInterface $form_state
   */
  protected function confirmPayment(array &$form, FormStateInterface $form_state)
  {
    $form['#theme'] = 'confirm_payment';
    $values = $form_state->getValues();

    $form['payment_confirmation'] = [
      '#type' => 'hidden',
      '#value' => false,
      '#default_value' => false,
    ];

    $form['email_status'] = [
      '#type' => 'hidden',
      '#value' => false,
      '#default_value' => false,
    ];

    $account_info = $form_state->get(['storage', 'accountSearch']);
    $form['#account_number'] = $account_info['search_account_number'];

    $paymentService = \Drupal::service('payment.xmlrpc_service');
    $form['#payment_amount'] = $paymentService->getAmountToPay($values);

    if ((int) $values['amount_to_pay'] === 3 && intval($values['other_payment_amount']) < intval($account_info['minimum_due'])) {
      drupal_set_message('Please note that the amount to pay is less than the amount due. This may result in cancellation of the policy if the amount due is not paid in a timely fashion.', 'warning');
    }

    $form['#payment_type'] = $values['account_details_payment_method'];
    if ($values['account_details_payment_method'] == 'CC') {
      $form['#payment_account'] = $values['card_number'];
      $form['#payment_account_masked'] = 'xxxxxxxxxxx' . substr($values['card_number'], -4);
      $form['#payment_method'] = 'credit card account';
      // $form['#payment_account_expires'] = $values['month'] . '-' . $values['year'];
      // $form['#payment_account_ccv'] = $values['card_verification_number'];
      $form['#billing_name'] = $values['billing_first_name'] . ' ' . $values['billing_last_name'];
      $form['#billing_street'] = $values['billing_street'];
      $form['#billing_city'] = $values['billing_city'];
      $form['#billing_state'] = $values['billing_state'];
      $form['#billing_zip'] = $values['billing_zip_code'];
    }

    if ($values['account_details_payment_method'] == 'EFT') {
      $form['#payment_account'] = $values['eft_account_number'];
      $form['#payment_account_masked'] = 'xxxxxxxxxxx' . substr($values['eft_account_number'], -4);
      $form['#payment_method'] = 'bank account (' . $values['eft_account_type'] . ')';
      $form['#account_routing'] = $values['eft_routing_number'];
      $form['#account_type'] = $values['eft_account_type'];
      $form['#account_name'] = $values['eft_name'];
    }

    $form['#email'] = !empty($values['new_email']) ? $values['new_email'] : (isset($account_info['email']) && !empty($account_info['email']) ? $account_info['email'] : '');
    $form['actions']['next']['#value'] = 'Confirm';
  }

  /**
   * Validate the customer's payment selections.
   *
   * @param array $form
   * @param FormStateInterface $form_state
   */
  protected function confirmPaymentValidate(array &$form, FormStateInterface $form_state)
  {

    // DO NOT process payment transactions on click of the previous button.
    $triggering_element = $form_state->getTriggeringElement();
    if ($triggering_element['#name'] == 'continue') {
      $accountValues = $form_state->get(['storage', 'accountDetails']);
      $paymentType = $accountValues['account_details_payment_method'];
      $paymentService = \Drupal::service('payment.xmlrpc_service');
      $payment_type_text = $paymentService->expandAcronym($paymentType);
      switch ($paymentType) {
        case 'CC':
          $response = $this->process_CC_payment($form_state);
          if (!empty($response) && (isset($reponse['status']) && $response['status'] != 'ACCEPT')) {
            $cc_error = $result['reply_message'];
            if ($cc_error) {
              $form_state->setErrorByName('payment_confirmation', t('Error processing your %payment_type payment -- @error', ['%payment_type' => $payment_type_text, '@error' => $cc_error]));
            } else {
              $form_state->setErrorByName('payment_confirmation', t('Error processing your %payment_type payment. Please contact customer service if this error continues and process your payment by phone.', ['%payment_type' => $payment_type_text]));
            }
          }
          $form_state->setValue('payment_confirmation', $response['confirmation_number']);
          break;
        case 'EFT':
          $response = $this->process_EFT_payment($form_state);
          if (!$response) {
            $form_state->setErrorByName('payment_confirmation', t('Error processing your %payment_type payment. Please check the account numbers.', ['%payment_type' => $payment_type_text]));
          }

          $form_state->setValue('payment_confirmation', $response);
          break;
        default:
        // Nothing to do here.
      }

      // Make sure payment_confirmation is false if there are errors.
      if ($form_state->hasAnyErrors() || !$response) {
        $form_state->setValue('payment_confirmation', false);
      } else {
        drupal_set_message(t(
            'Your %payment_type payment has been successfully processed. '
            . '<br /> Please do not click the Back button in your browser. '
            . '<br />You may print this page for your records.', ['%payment_type' => $payment_type_text]));
      }
    }
  }

  /**
   * Submit the customer's payment selections. This finalizes the payment.
   *
   * @param array $form
   * @param FormStateInterface $form_state
   */
  protected function confirmPaymentSubmit(array &$form, FormStateInterface $form_state)
  {

    // DO NOT send and email on click of the previous button.
    $triggering_element = $form_state->getTriggeringElement();
    if ($triggering_element['#name'] == 'continue') {
      // payment_confirmation is set in confirmPaymentValidate(). Default is false.
      if ((bool) $form_state->getValue('payment_confirmation')) {
        $accountValues = $form_state->get(['storage', 'accountDetails']);
        $paymentType = $accountValues['account_details_payment_method'];
        $paymentService = \Drupal::service('payment.xmlrpc_service');
        $payment_type_text = $paymentService->expandAcronym($paymentType);

        $module = 'payment';
        $key = 'receipt_mail';
        $to = $this->get_chosen_email($accountValues);
        $from = $this->config('system.site')->get('mail');
        $message = '<p>Hi ' . $accountValues['billing_first_name'] ? (ucfirst($accountValues['billing_first_name']) . ',') : '' . '</p>';
        $message .= '<p>' . t('Your recent RVOS Payment Was Successful.') . '</p>';
        $message .= '<p>' . t('Thank you for making a payment to your account. This email is to confirm that your payment for $@amount has been successfully processed. Please note it may take 1-2 business days for this payment to be applied to your account.', array('@amount' => $paymentService->getAmountToPay($accountValues))) . '</p>';
        $message .= '<p>' . t('Payment Summary : ') . '</p>';
        $message .= '<p>' . t('Account number: @accountNumber', array('@accountNumber' => $accountValues['account_number'])) . '</p>';
        $message .= '<p>' . t('Amount Paid: $@amount', array('@amount' => $paymentService->getAmountToPay($accountValues))) . '</p>';
        $message .= '<p>' . t('Payment reference number: @method-@reference', array('@method' => $accountValues['account_details_payment_method'], '@reference' => $form_state->getValue('payment_confirmation'))) . '</p>';
        $message .= '<p>' . t('Thank you for your business.') . '</p>';
        $message .= '<p>' . t('If you have any questions, please contact your agent or call Customer Service during business hours at 1-800-792-3084.') . '</p>';

        $params = array(
          'body' => MailFormatHelper::htmlToText($message),
        );
        $language_code = $this->languageManager->getDefaultLanguage()->getId();
        $send = TRUE;

        $result = $this->mailManager->mail($module, $key, $to, $language_code, $params, $from, $send);
        $form_state->setValue('email_status', $result['result']);
        if ($result['result'] == TRUE) {
          drupal_set_message('Payment confirmation email has been sent to your mail id.');
        } else {
          drupal_set_message(t('There was a problem sending mail.'), 'error');
        }
      }
    }
  }

  public function paymentSuccess(array &$form, FormStateInterface $form_state)
  {
    $form['#theme'] = 'payment_success';
    $values = $form_state->getValues();
    $accountDetails = $form_state->get(['storage', 'accountDetails']);
    $paymentService = \Drupal::service('payment.xmlrpc_service');

   // dsm($values, 'form state values');

    $account_info = $form_state->get(['storage', 'accountSearch']);
    $form['#account_number'] = $account_info['search_account_number'];
    $form['#payment_amount'] = $paymentService->getAmountToPay($accountDetails);

    if ((int) $accountDetails['amount_to_pay'] === 3 && intval($accountDetails['other_payment_amount']) < intval($account_info['minimum_due'])) {
      drupal_set_message(t('Please note that the amount to pay is less than the amount due. This may result in cancellation of the policy if the amount due is not paid in a timely fashion.'), 'warning');
    }

    $form['#payment_confirmation'] = $form_state->getValue('payment_confirmation');
    $form['#email_status'] = $form_state->getValue('email_status');

    $form['#payment_type'] = $accountDetails['account_details_payment_method'];
    if ($accountDetails['account_details_payment_method'] == 'CC') {
      $form['#payment_account'] = $accountDetails['card_number'];
      $form['#payment_account_masked'] = 'xxxxxxxxxxx' . substr($accountDetails['card_number'], -4);
      $form['#payment_method'] = 'credit card';
    }

    if ($accountDetails['account_details_payment_method'] == 'EFT') {
      $form['#payment_account'] = $accountDetails['eft_account_number'];
      $form['#payment_account_masked'] = 'xxxxxxxxxxx' . substr($accountDetails['eft_account_number'], -4);
      $form['#payment_method'] = 'bank account (' . $accountDetails['eft_account_type'] . ')';
    }

    $form['#email'] = !empty($accountDetails['new_email']) ? $accountDetails['new_email'] : (isset($account_info['email']) && !empty($account_info['email']) ? $account_info['email'] : '');
  }

  public function paymentSuccessValidate(array &$form, FormStateInterface $form_state)
  {

  }

  public function paymentSuccessSubmit(array &$form, FormStateInterface $form_state)
  {
    
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state)
  {

    //$this->finalizedRedirectPath = 'payment.makepayment';
    // The form settings are empty. Notify the user of an error with the form
    // configuration settings and provide a means to contact support, or if the
    // current user is an admin, provide a link to the module configuraion page.
    if (empty($this->config->get('payment_webservice')) || empty($this->config->get('payment_lookup_webservice'))) {
      $user = \Drupal::currentUser();
      $markup = t('RVOS Payment is currently unavailable. Please contact <a href="mailto:computerservices@rvos.com&subject=Czechpoint%20payments%20are%20unavailable">computer services</a> if believe this to be in error.');
      if ($user->hasPermission('administer site configuration') || $user->hasPermission('administer payments')) {
        $payment_settings_url = Url::fromRoute('payment_settings');
        $markup .= '<br />' . t('Please visit <a href="@payment_settings_url" />Payment Settings</a> to configure the payment module.', ['@payment_settings_url' => $payment_settings_url->toString()]);
      }
      $form['not_configured'] = [
        '#type' => 'markup',
        '#markup' => $markup,
      ];
      return $form;
    }

    $this->setStep($form_state);
    $step = $this->step;
    $form['step'] = [
      '#type' => 'hidden',
      '#value' => $step,
    ];

    $fn = $this->steps[$step];
    $form_state->set('step_name', $fn);
    if ($step > 1) {
      $form_state->set('prev_step_name', $this->steps[$step - 1]);
    }

    // Bad form step function name?
    if (!method_exists($this, $fn)) {
      return $this->stepNotExist($form);
    }

    // Build the step actions.
    $this->formActions($form, $form_state);

    // Build the step.
    $this->$fn($form, $form_state);

    // Return the form step.
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state)
  {
    parent::validateForm($form, $form_state);

    $triggering_element = $form_state->getTriggeringElement();
    if ($triggering_element['#name'] == 'previous') {
      // Do not validate the form fields.
      $form_state->setLimitValidationErrors([]);
    }
    // process the validation for the given step
    $step = $this->step;
    $stepName = $this->buildSteps()[$step];
    $fn = $stepName . 'Validate';
    if (method_exists($this, $fn)) {
      $this->$fn($form, $form_state);
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state)
  {
    // Get the current step
    $step = $this->step;
    // Process the submit handler for the current step IF it has been defined.
    $stepName = $this->buildSteps()[$step];
    $fn = $stepName . 'Submit';
    //dsm($fn, 'submit function');
    if (method_exists($this, $stepName)) {
      $this->$fn($form, $form_state);
    }

    // Save the step information to the form state storage.
    // Don't save the step information on the final step (#name = 'submit').
    // This allows us to retrieve the form step values while navigating between
    // steps and to set the #default_values according to what was previously
    // submitted for a give step.
    $triggering_element = $form_state->getTriggeringElement();
    if ($triggering_element['#name'] != 'submit') {
      $form_state->set(['storage', $form_state->get('step_name')], $form_state->getValues());
    }
  }

  /**
   * Tells the form to redirect to the home page. Clears entered values from
   * the session storage.
   *
   * @param array $form
   * @param FormStateInterface $form_state
   */
  public function cancelPayment(array &$form, FormStateInterface $form_state)
  {
    // Clear the form state storage values.
    $form_state->set('storage', []);
    // Redirect to the home page.
    $form_state->setRedirect('<front>');
  }

  public function previousStep(array &$form, FormStateInterface $form_state)
  {
    // Get the current step
    $step = $this->step;
    $stepName = $this->buildSteps()[$step];
    // Set the step value to the previous page.
    $form_state->setValue('step', $step - 1);
    // We have to rebuild the form state else the step value will be empty
    // and we'll be returned to step 1.
    $form_state->setRebuild(true);
    // Restore step values for previous step.
    // The current form state values are stored by submitForm() in form_state.
    if ($step > 1) {
      $prev_step = $this->buildSteps()[$form_state->getValue('step')];
      $step_values = $form_state->get(['storage', $prev_step]);
      $form_state->setValues($step_values);
    }
  }

  public function nextStep(array &$form, FormStateInterface $form_state)
  {
    // Get the current step
    $step = $this->step;
    $stepName = $this->buildSteps()[$step];

    // Set the step value to the next step.
    $form_state->setValue('step', $step + 1);

    // We have to rebuild the form state else the step value will be empty
    // and we'll always be on step 1.
    $form_state->setRebuild(true);
    $step_values = $form_state->get(['storage', $stepName]);
    if (!empty($step_values)) {
      // Keep the values most recently submitted by merging form state values
      // in last.
      $form_state->setValues(array_merge($step_values, $form_state->getValues()));
    }
  }

  public function finalStep(array &$form, FormStateInterface $form_state)
  {
    // Clear the form storage.
    //   $form_state->set('storage', []);
    
    // end requires a reference, because it modifies the internal representation of the array (end is used to make the current element pointer point to the last element).
    $laststep = array_keys($this->buildSteps());
    $form_state->setValue('step', end($laststep));
    
    // We shouldn't have to do a redirect here as we should get redirected
    // to step 1 with the statements above.
  }

  /**
   * Sets the steps and the current step.
   * @param FormStateInterface $step
   */
  private function setStep(FormStateInterface $form_state)
  {
    $steps = $this->steps = $this->buildSteps();
    $step = $form_state->getValue('step');

    if (empty($step)) {
      $step = 1;
      $form_state->setValue('step', $step);
    }
    $this->step = $step;
  }

  private function stepNotExist(array $form)
  {
    $mailto = 'operations@rvos.com';
    $inbox = 'Computer Operations';
    $subject = $this->t('Payment step error');
    $body = $this->t('An error occurred in the step navigation for the Payment module while navigating to step @step.', ['@step' => $step]);
    $form['error']['step_not_exists'] = [
      '#type' => 'markup',
      '#markup' => '<p>An error occurred while processing your request.</p>'
      . '<p>If you continue to get this error please contact '
      . '<a href="mailto:' . $mailto . '?subject=' . rawurlencode($subject) . '&body=' . rawurlencode($body) . '">' . $inbox . '</a>.',
    ];
    drupal_set_message($body, 'error');
    $this->logger('payment')->error($body);
    // Return with the navigation error.
    return $form;
  }

  private function formActions(array &$form, FormStateInterface $form_state)
  {
    // Establish our steps and current step.
    $steps = $this->steps;
    $step = $this->step;

    // Determine the last step in the process.
    end($steps);
    $last_step = key($steps);
    // Deterine the first step in the process.
    reset($steps);
    $first_step = key($steps);

    // Form actions container. Make sure it is the last element; Weight = 999.
    $form['actions'] = [
      '#type' => 'actions',
      '#prefix' => '<div class="container-inline">',
      '#suffix' => '</div>',
      '#weight' => 999,
    ];

    // Create the cancel button for the first step.
    if ((int) $step == 1) {
      $previousButtonText = t('Cancel');
      $previousSubmit = 'cancelForm';
    }

    // Include a previous button for steps greater than 1.
    if ((int) $step > (int) $first_step) {
      $previousButtonText = t('Previous');
      $previousSubmit = 'previousStep';
    }

    $form['actions']['previous'] = [
      '#type' => 'submit',
      '#value' => $previousButtonText,
      '#prefix' => '<span class="text-align-left span-half-width">',
      '#suffix' => '</span>',
      '#name' => 'previous',
      '#attributes' => ['class' => ['btn-primary']],
      '#limit_validation_errors' => [],
    ];
    $form['actions']['previous']['#submit'][] = [$this, 'submitForm'];
    $form['actions']['previous']['#submit'][] = [$this, $previousSubmit];
    $form['actions']['previous']['#validate'][] = [$this, 'validateForm'];


    // Setup the button text and name for the next step or final submit button
    // which completes the process.
    $nextButtonText = t('Submit');
    $nextButtonName = 'submit';
    $nextSubmit = 'finalStep';
    if ((int) $step !== (int) $last_step) {
      $nextButtonText = t('Next');
      $nextButtonName = 'continue';
      $nextSubmit = 'nextStep';
    }

    $next_classes = [
      empty($form['actions']['previous']) ? 'text-align-left' : 'text-align-right',
      empty($form['actions']['previous']) ? 'span-full-width' : 'span-half-width',
    ];

    $form['actions']['next'] = [
      '#type' => 'submit',
      '#value' => $nextButtonText,
      '#prefix' => '<span class="' . implode(' ', $next_classes) . '">',
      '#suffix' => '</span>',
      '#name' => $nextButtonName,
      '#attributes' => ['class' => [
          'btn-primary',
        ],
      ],
    ];
    $form['actions']['next']['#submit'][] = [$this, 'submitForm'];
    $form['actions']['next']['#submit'][] = [$this, $nextSubmit];
  }

  /**
   *  Account info from first webservice call formatted for use
   */
  private function build_account_details_info($form_state)
  {
    $past_due = $form_state->getValue('past_due');
    $balance = $form_state->getValue('balance');
    $insured_account_number = $form_state->getValue('account_number');
    $due_date = $form_state->getValue('due_date');
    $amount_due = $form_state->getValue('minimum_due');

    if ($past_due == 'Y') {
      drupal_set_message(t('<strong>Your account is past due. Please contact customer service immediately to make a payment and reinstate the policy.</strong>'));
      $futurePast = 'was';
    } else {
      $futurePast = 'is';
    }

    if ($balance == 0) {
      $account_details_html = "<h2>Account: #" . $insured_account_number . "</h2>
      <P><b>No Payment Due</b>
      <P>There is no balance due on your account. <P>Please contact customer service at 1-800-792-3084 if you have any questions.
      <BR>
      </P>";
      return $account_details_html;
    } elseif ($amount_due == 0) {
      $account_details_html = "<h2>Account: #" . $insured_account_number . "</h2>
      <p>You do not currently have a payment due.</b>
      <BR>The total remaining balance on the policy is: <b>$" . $balance . "</b>
      </p>";
      return $account_details_html;
    } else {
      $account_details_html = "<h2>Account: #" . $insured_account_number . "</h2>
      <p>Your payment of <b>$" . $amount_due . "</b> " . $futurePast . " due on <b>" . $due_date . ".</b>
      <BR>The total remaining balance on the policy is: <b>$" . $balance . "</b>
      </p>";
      return $account_details_html;
    }
  }

  /**
   * Logic to return the email address they chose, or the default
   */
  private function get_chosen_email($payment_info)
  {
    if ($payment_info['email_receipts'] == 1) {
      $final_email_recipient = $payment_info['new_email'];
    } else {
      $final_email_recipient = $payment_info['email'];
    }
    return $final_email_recipient;
  }

  /**
   * reformat a string as an int
   */
  function toInt($str)
  {
    return preg_replace("/([^0-9\\.])/i", "", $str);
  }

  /**
   *  Format the email options for use in the form
   */
  private function format_email_options(FormStateInterface $form_state)
  {
    if ($form_state->getValue('email')) {
      $result['payee_email_address'] = array(0 => t('Use my email address on file: ' . $form_state->getValue('email_obscured')), 1 => t('Use this address:'));
      $result['email_description'] = "This address will be used one-time only. <BR>Contact customer service to permanently add or change account email.";
      $result['default_email_selection'] = 0;
    } else {
      $result['email_description'] = "This address will be used one-time only. <BR>Contact customer service to permanently add or change account email.";
      $result['payee_email_address'] = array(1 => t('Use this address'));
      $result['email_title'] = ' (None on file)';
      $result['default_email_selection'] = 1;
    }
    return $result;
  }

  /**
   * Reformat an email address as obscured, ie rxxxxxxxd@rvos.com
   */
  private function format_email_obscured($address)
  {
    $parts = explode('@', $address);
    $user = $parts[0];
    $domain = "@" . $parts[1];
    if (strlen($user) == 1) {
      $user2 = 'X';
    } elseif (strlen($user) == 2) {
      $user2 = substr($user, 0, 1) . str_repeat('X', (strlen($user) - 1));
    } else {
      $user2 = substr($user, 0, 1) . str_repeat('X', (strlen($user) - 2)) . substr($user, -1, 1);
    }
    $obscured = $user2 . $domain;
    return $obscured;
  }

  /**
   * Process a Credit Card
   */
  public function process_CC_payment(FormStateInterface $form_state)
  {
    // For some reason the class attribute $this->paymentService is empty?!
    // Print $this->paymentService out in constructor and step 1 work properly.
    // All other steps $this->paymentService is empty... Drupal bug?
    $paymentService = \Drupal::service('payment.xmlrpc_service');
    return $paymentService->processCreditCardPayment($form_state);
  }
  /*
   * Process an EFT
   * take the payment information and run it through the EFT webservice via xml-rpc
   */

  public function process_EFT_payment(FormStateInterface $form_state)
  {
    // For some reason the class attribute $this->paymentService is empty?!
    // Print $this->paymentService out in constructor and step 1 work properly.
    // All other steps $this->paymentService is empty... Drupal bug?
    $paymentService = \Drupal::service('payment.xmlrpc_service');
    return $paymentService->processElectronicFundsTransferPayment($form_state);
  }
}
