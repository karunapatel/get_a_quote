<?php
/*
 * @author Daniel Taylor <dtaylor@rvos.com>
 * Contains \Drupal\payment\Service\PaymentXmlrpcService
 */
namespace Drupal\payment\Service;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Form\FormStateInterface;
use Psr\Log\LoggerInterface;

/**
 *
 */
class PaymentXmlrpcService
{

  /**
   * @var Configuration
   */
  private $config;

  /**
   * @var Logger
   */
  private $logger;

  /**
   * Constructs a \Drupal\payment\Service\PaymentXmlrpcService object.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   * @param \Psr\Log\LoggerInterface $logger
   */
  public function __construct(ConfigFactoryInterface $config_factory, LoggerInterface $logger)
  {
    $this->config = $config_factory->get('payment.settings');
    $this->logger = $logger;
  }

  /**
   * Creates an instance for \Drupal\payment\Service\PaymentXmlrpcService.
   * 
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   * @param \Psr\Log\LoggerInterface $logger
   * @return \Drupal\payment\Service\PaymentXmlrpcService
   */
  public static function create(ConfigFactoryInterface $config_factory, LoggerInterface $logger)
  {
    return new static($config_factory, $logger);
  }

  /**
   * Processes a credit card payment using values provided by the current
   * \Drupal\Core\Form\FormStateInterface object.
   *
   * @param \Drupal\payment\Service\FormStateInterface $form_state
   */
  public function processCreditCardPayment(FormStateInterface $form_state)
  {    
    $account_information = $form_state->get(['storage', 'accountDetails']);

    $data = [
      $account_information['account_number'],
      '',
      $this->getAmountToPay($account_information),
      $account_information['card_number'],
      $account_information['month'] . "/" . substr($account_information['year'], -2),
      $account_information['billing_first_name'],
      $account_information['billing_last_name'],
      $account_information['billing_street'],
      $account_information['billing_city'],
      $account_information['billing_state'],
      $account_information['billing_zip_code'],
      'payments@rvos.com',
      \Drupal::request()->getClientIp(),
      $account_information['card_verification_number'],
      '0',
      'rvos.com',
      $account_information['full_name'],
      \Drupal::currentUser()->getAccountName(),
    ]; 

    //dsm($data, 'data');

    $response = $this->handle(['Payment.processCreditCard' => $data], 'CC');

    //dsm($response, 'cc response');

    // Additional processing of CC response below this line.

    // Return the response
    return $response;
  }

  /**
   * Processes an electronic funds transfer payment using values provided by the
   * current \Drupal\Core\Form\FormStateInterface object.
   *
   * @param \Drupal\payment\Service\FormStateInterface $form_state
   */
  public function processElectronicFundsTransferPayment(FormStateInterface $form_state)
  {
    $account_information = $form_state->get(['storage', 'accountDetails']);

    $data = [
      $account_information['eft_routing_number'],
      $account_information['eft_account_number'],
      $account_information['eft_account_type'],
      $account_information['eft_name'],
      $account_information['account_number'],
      $this->getAmountToPay($account_information),
      \Drupal::request()->getClientIp(),
      'rvos.com',
      $account_information['full_name'],
      \Drupal::currentUser()->getAccountName(),
    ];
    
    //dsm($data, 'data');

    $response = $this->handle(['Payment.processACH' => $data], 'EFT');

    //dsm($response, 'eft response');

    return $response;
  }

  private function handle(array $xmlRpcArgs, $type)
  {
    $endpoint = $this->config->get('payment_webservice');    
    $response = xmlrpc($endpoint, $xmlRpcArgs);

    //dsm($response, 'payment webservice response');

    if ($xml_error = xmlrpc_error_msg()) {
      $this->logger->error(t('XML-RPC error in %type process. @error', ['%type' => $this->expandAcronym($type), '@error' => $xml_error]));
    }

    if (!empty($response)) {
      return $response;
    }
    
    return false;
  }

  /**
   * Expands an acronym into its full text representation.
   * Returns uppercase acronym if expanded representation fails.
   *
   * @param string $acronym
   * @return string
   */
  public function expandAcronym($acronym) {
    switch (strtolower($acronym)) {
      case 'cc':
        $text = 'credit card';
        break;
      case 'eft':
        // Not the true represention, which is Electronic Funds Transfer.
        // However, this is what we need for business rules.
        $text = 'bank account';
        break;
      default:
        $text = strtoupper($acronym);
    }
    return $text;
  }

  /**
   *
   * @param array $account_info
   * @return boolean|array
   */
  public function getAmountToPay(array $account_info)
  {
    switch ((int) $account_info['amount_to_pay']) {
      case 1:
        return $account_info['minimum_due'];
        break;
      case 2:
        return $account_info['balance'];
        break;
      case 3:
        return $account_info['other_payment_amount'];
        break;
      default:
        // Should never happen...
        return false;
    }
  }
}
