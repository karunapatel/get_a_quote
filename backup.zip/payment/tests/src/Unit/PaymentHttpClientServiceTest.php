<?php
/*
 * @author Daniel Taylor <dtaylor@rvos.com>
 * Contains \Drupal\Tests\payment\PaymentHttpClientService
 */
namespace Drupal\Tests\payment\Unit;

use Drupal\payment\Service\PaymentHttpClientService;
use Drupal\Tests\UnitTestCase;
use Drupal\simpletest\WebTestBase;
use Drupal\Tests\BrowserTestBase;

class PaymentHttpClientServiceTest extends UnitTestCase
{
  public $paymentService;

  public function setup()
  {
    $this->paymentService = new PaymentHttpClientService();
  }

  public function testCustomerSearch()
  {
    ;
  }
}
